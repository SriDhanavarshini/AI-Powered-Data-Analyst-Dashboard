-- Power BI-ready views: a clean star schema on top of the transactional
-- tables, so Power BI's relationship view maps cleanly without needing
-- business logic baked into the report itself.

CREATE OR REPLACE VIEW vw_fact_orders AS
SELECT
    o.order_id,
    o.customer_id,
    o.product_id,
    o.order_date,
    o.quantity,
    o.unit_price,
    o.discount,
    o.revenue,
    o.cost,
    o.profit,
    o.region,
    o.sales_channel,
    o.order_status
FROM orders o
WHERE o.order_status = 'Completed';

CREATE OR REPLACE VIEW vw_dim_customers AS
SELECT customer_id, name, gender, age, city, state, region, signup_date, customer_segment
FROM customers;

CREATE OR REPLACE VIEW vw_dim_products AS
SELECT product_id, product_name, category, subcategory, price, cost, supplier
FROM products;

CREATE OR REPLACE VIEW vw_dim_date AS
-- Power BI can also auto-generate a date table; this view is provided for
-- databases/report authors who prefer an explicit one.
SELECT DISTINCT
    order_date AS date,
    strftime('%Y', order_date) AS year,
    strftime('%m', order_date) AS month_num,
    strftime('%Y-%m', order_date) AS year_month
FROM orders;
