# Power BI integration

## Connecting

1. Run `views.sql` against your MySQL database (`docker compose exec mysql mysql -u root -p ai_analyst < powerbi/views.sql`,
   or adapt the syntax — MySQL doesn't support `CREATE OR REPLACE VIEW` on
   very old versions; MySQL 8 does).
2. In Power BI Desktop: **Get Data → MySQL database**.
3. Server: `localhost:3306` (or your host), Database: `ai_analyst`.
4. Use a **read-only** MySQL user for this connection — do not use the
   application's write-capable credentials. Create one with:
   ```sql
   CREATE USER 'powerbi_reader'@'%' IDENTIFIED BY 'choose-a-password';
   GRANT SELECT ON ai_analyst.* TO 'powerbi_reader'@'%';
   ```
5. Import `vw_fact_orders`, `vw_dim_customers`, `vw_dim_products`.

## Building the model

- Set `vw_fact_orders` as the fact table.
- Relationships: `vw_fact_orders[customer_id] → vw_dim_customers[customer_id]`
  (many-to-one), `vw_fact_orders[product_id] → vw_dim_products[product_id]`
  (many-to-one).
- Mark `vw_dim_customers` and `vw_dim_products` as dimension tables in the
  model view.
- Either let Power BI auto-generate a date hierarchy from `order_date`, or
  import `vw_dim_date` and relate it on `order_date` if you want a
  standalone date table for time-intelligence DAX functions.

## Suggested measures (DAX)

```
Total Revenue = SUM(vw_fact_orders[revenue])
Total Profit = SUM(vw_fact_orders[profit])
Profit Margin % = DIVIDE([Total Profit], [Total Revenue])
Order Count = COUNTROWS(vw_fact_orders)
Average Order Value = DIVIDE([Total Revenue], [Order Count])
```

These mirror the same business definitions used in
`app/database/queries.py` (`SCHEMA_DESCRIPTION`), so the AI Analyst chat and
the Power BI report will always agree on what "revenue" and "AOV" mean.

## Refresh

For scheduled refresh (Power BI Service), point the gateway at the same
read-only MySQL user. This app's own dashboard (Streamlit) and Power BI can
run side-by-side against the same database without conflict, since both
only read.
