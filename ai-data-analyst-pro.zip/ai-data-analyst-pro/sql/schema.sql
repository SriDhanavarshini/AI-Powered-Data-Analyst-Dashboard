-- AI Data Analyst Pro — schema (MySQL-compatible; SQLAlchemy also creates this from models.py for SQLite)

CREATE TABLE IF NOT EXISTS customers (
    customer_id       INT PRIMARY KEY AUTO_INCREMENT,
    name              VARCHAR(120) NOT NULL,
    gender            VARCHAR(20),
    age               INT,
    city              VARCHAR(80),
    state             VARCHAR(80),
    region            VARCHAR(40),
    signup_date       DATE,
    customer_segment  VARCHAR(40)
);

CREATE TABLE IF NOT EXISTS products (
    product_id     INT PRIMARY KEY AUTO_INCREMENT,
    product_name   VARCHAR(120) NOT NULL,
    category       VARCHAR(60),
    subcategory    VARCHAR(60),
    price          DECIMAL(10,2),
    cost           DECIMAL(10,2),
    supplier       VARCHAR(80)
);

CREATE TABLE IF NOT EXISTS orders (
    order_id       INT PRIMARY KEY AUTO_INCREMENT,
    customer_id    INT NOT NULL,
    product_id     INT NOT NULL,
    order_date     DATE NOT NULL,
    quantity       INT,
    unit_price     DECIMAL(10,2),
    discount       DECIMAL(5,2),
    revenue        DECIMAL(12,2),
    cost           DECIMAL(12,2),
    profit         DECIMAL(12,2),
    region         VARCHAR(40),
    sales_channel  VARCHAR(40),
    order_status   VARCHAR(30),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

CREATE TABLE IF NOT EXISTS payments (
    payment_id      INT PRIMARY KEY AUTO_INCREMENT,
    order_id        INT NOT NULL,
    payment_method  VARCHAR(40),
    payment_status  VARCHAR(30),
    payment_date    DATE,
    FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

CREATE TABLE IF NOT EXISTS returns (
    return_id      INT PRIMARY KEY AUTO_INCREMENT,
    order_id       INT NOT NULL,
    return_date    DATE,
    return_reason  VARCHAR(120),
    refund_amount  DECIMAL(10,2),
    FOREIGN KEY (order_id) REFERENCES orders(order_id)
);
