"""Executes validated SQL against the database and returns a DataFrame."""

import pandas as pd
from sqlalchemy import text

from app.config import settings
from app.database.connection import engine
from app.utils.logger import get_logger
from app.validation.sql_validator import validate_sql

logger = get_logger("sql_tool")


def run_sql(sql: str) -> pd.DataFrame:
    safe_sql = validate_sql(sql, max_rows=settings.MAX_QUERY_ROWS)
    logger.info(f"Executing SQL: {safe_sql[:200]}")
    with engine.connect() as conn:
        result = conn.execute(text(safe_sql))
        rows = result.fetchall()
        cols = result.keys()
    return pd.DataFrame(rows, columns=cols)
