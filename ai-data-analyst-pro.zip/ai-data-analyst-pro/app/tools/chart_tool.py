"""Chooses an appropriate chart type + builds a Plotly figure from a result DataFrame."""

import pandas as pd
import plotly.express as px


def auto_chart(df: pd.DataFrame, title: str = ""):
    if df.empty:
        return None

    numeric_cols = df.select_dtypes(include="number").columns.tolist()
    non_numeric = [c for c in df.columns if c not in numeric_cols]

    if not numeric_cols:
        return None

    # time-series -> line
    date_like = [c for c in non_numeric if "date" in c.lower() or "month" in c.lower()]
    if date_like:
        return px.line(df, x=date_like[0], y=numeric_cols[0], title=title, markers=True)

    # single categorical + single numeric, few categories -> bar or pie
    if len(non_numeric) == 1 and len(numeric_cols) >= 1:
        cat_col = non_numeric[0]
        if df[cat_col].nunique() <= 6 and len(df) <= 6:
            return px.pie(df, names=cat_col, values=numeric_cols[0], title=title)
        return px.bar(df, x=cat_col, y=numeric_cols[0], title=title)

    # two numeric columns -> scatter
    if len(numeric_cols) >= 2:
        return px.scatter(df, x=numeric_cols[0], y=numeric_cols[1], title=title)

    return px.bar(df, y=numeric_cols[0], title=title)
