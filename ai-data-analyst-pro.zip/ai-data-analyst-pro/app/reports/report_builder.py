"""
Automated report generation: assembles a KPI summary, trends, anomalies,
top drivers, forecast, and recommendation into one report dict, then
renders it to PDF, Excel, or CSV.
"""

from datetime import datetime

import pandas as pd

from app.agents.recommendation_agent import recommend_from_regional_gap
from app.analytics.anomaly import detect_anomalies
from app.analytics.forecasting import forecast_series
from app.analytics.metrics import kpi_summary
from app.database import queries as Q
from app.tools.sql_tool import run_sql


def build_report_data(period: str = "monthly") -> dict:
    """period: 'daily' | 'weekly' | 'monthly' — controls the report title only;
    the underlying data is the full history (synthetic data doesn't have
    enough daily granularity of events to meaningfully window by day)."""
    orders_df = run_sql("SELECT * FROM orders")
    kpis = kpi_summary(orders_df)

    monthly = run_sql(Q.Q_MONTHLY_REVENUE)
    anomalies = detect_anomalies(monthly, "month", "revenue")
    forecast = forecast_series(monthly, "revenue", periods=3)

    region_df = run_sql(Q.Q_REGIONAL_PERFORMANCE)
    category_df = run_sql(Q.Q_CATEGORY_PERFORMANCE)
    recommendation = recommend_from_regional_gap(region_df)

    return {
        "period": period,
        "generated_at": datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"),
        "kpis": kpis,
        "monthly_revenue": monthly.to_dict(orient="records"),
        "anomalies": anomalies.to_dict(orient="records"),
        "forecast": forecast.to_dict(orient="records"),
        "region_performance": region_df.to_dict(orient="records"),
        "category_performance": category_df.to_dict(orient="records"),
        "recommendation": recommendation,
    }


def render_html(report: dict) -> str:
    kpis = report["kpis"]
    rows_anomalies = (
        "".join(
            f"<tr><td>{a['month']}</td><td>{a['revenue']}</td><td>{a['deviation_pct']}%</td><td>{a['severity']}</td></tr>"
            for a in report["anomalies"]
        )
        or "<tr><td colspan='4'>No anomalies detected</td></tr>"
    )

    rows_regions = "".join(
        f"<tr><td>{r['region']}</td><td>{r['revenue']:,.0f}</td><td>{r['profit']:,.0f}</td><td>{r['orders']}</td></tr>"
        for r in report["region_performance"]
    )

    rec = report["recommendation"]
    rec_html = (
        f"<p><b>Finding:</b> {rec['finding']}</p><p><b>Evidence:</b> {rec['evidence']}</p>"
        f"<p><b>Possible driver:</b> {rec['possible_driver']}</p>"
        f"<p><b>Recommendation:</b> {rec['recommendation']}</p>"
        f"<p><b>Expected impact:</b> {rec['expected_impact']}</p>"
        if rec
        else "<p>No significant driver gap detected this period.</p>"
    )

    return f"""
    <html><head><style>
        body {{ font-family: Arial, sans-serif; margin: 40px; color: #222; }}
        h1 {{ color: #4b3f9e; }}
        table {{ border-collapse: collapse; width: 100%; margin-bottom: 24px; }}
        th, td {{ border: 1px solid #ddd; padding: 6px 10px; text-align: left; font-size: 13px; }}
        th {{ background: #f4f2fc; }}
        .kpi-row span {{ display: inline-block; margin-right: 24px; font-size: 14px; }}
        .kpi-row b {{ font-size: 18px; }}
    </style></head><body>
        <h1>AI Data Analyst Pro — {report['period'].capitalize()} Report</h1>
        <p>Generated: {report['generated_at']}</p>

        <h2>KPI Summary</h2>
        <div class="kpi-row">
            <span>Revenue<br><b>₹{kpis['revenue']:,.0f}</b></span>
            <span>Profit<br><b>₹{kpis['profit']:,.0f}</b></span>
            <span>Orders<br><b>{kpis['orders']:,}</b></span>
            <span>AOV<br><b>₹{kpis['aov']:,.0f}</b></span>
            <span>Margin<br><b>{kpis['profit_margin_pct']}%</b></span>
        </div>

        <h2>Anomalies</h2>
        <table><tr><th>Month</th><th>Revenue</th><th>Deviation</th><th>Severity</th></tr>{rows_anomalies}</table>

        <h2>Regional Performance</h2>
        <table><tr><th>Region</th><th>Revenue</th><th>Profit</th><th>Orders</th></tr>{rows_regions}</table>

        <h2>Recommendation</h2>
        {rec_html}
    </body></html>
    """


def export_pdf(report: dict, output_path: str) -> str:
    from weasyprint import HTML

    HTML(string=render_html(report)).write_pdf(output_path)
    return output_path


def export_excel(report: dict, output_path: str) -> str:
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        pd.DataFrame([report["kpis"]]).to_excel(writer, sheet_name="KPIs", index=False)
        pd.DataFrame(report["monthly_revenue"]).to_excel(
            writer, sheet_name="Monthly Revenue", index=False
        )
        pd.DataFrame(report["anomalies"]).to_excel(writer, sheet_name="Anomalies", index=False)
        pd.DataFrame(report["forecast"]).to_excel(writer, sheet_name="Forecast", index=False)
        pd.DataFrame(report["region_performance"]).to_excel(
            writer, sheet_name="Regions", index=False
        )
        pd.DataFrame(report["category_performance"]).to_excel(
            writer, sheet_name="Categories", index=False
        )
    return output_path


def export_csv(report: dict, output_path: str) -> str:
    """CSV can only hold one table — exports the monthly revenue trend,
    the most universally useful single table for a quick CSV pull."""
    pd.DataFrame(report["monthly_revenue"]).to_csv(output_path, index=False)
    return output_path
