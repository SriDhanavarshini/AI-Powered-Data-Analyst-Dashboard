"""
Simple churn-risk classifier. Labels a customer "churned" if their most
recent order is older than `churn_days` relative to the dataset's max date —
this is a heuristic label (no ground truth exists in synthetic data), so
predictions are explicitly framed as risk scores, not certainties.
"""

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split


def build_churn_features(orders_df: pd.DataFrame, churn_days: int = 90) -> pd.DataFrame:
    df = orders_df[orders_df["order_status"] == "Completed"].copy()
    df["order_date"] = pd.to_datetime(df["order_date"])
    ref = df["order_date"].max()

    features = (
        df.groupby("customer_id")
        .agg(
            frequency=("order_id", "count"),
            total_spend=("revenue", "sum"),
            avg_order_value=("revenue", "mean"),
            days_since_last=("order_date", lambda x: (ref - x.max()).days),
            tenure_days=("order_date", lambda x: (x.max() - x.min()).days),
        )
        .reset_index()
    )

    features["churned"] = (features["days_since_last"] > churn_days).astype(int)
    return features


def train_churn_model(features: pd.DataFrame):
    X = features[["frequency", "total_spend", "avg_order_value", "tenure_days"]]
    y = features["churned"]

    if y.nunique() < 2 or len(features) < 20:
        return None, None  # not enough signal to train meaningfully

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)
    model = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=42)
    model.fit(X_train, y_train)
    accuracy = model.score(X_test, y_test)
    return model, round(float(accuracy), 3)


def predict_churn_risk(model, features: pd.DataFrame) -> pd.DataFrame:
    X = features[["frequency", "total_spend", "avg_order_value", "tenure_days"]]
    proba = model.predict_proba(X)[:, 1]
    out = features[["customer_id"]].copy()
    out["churn_probability"] = proba.round(3)
    out["risk_category"] = pd.cut(
        proba, bins=[-0.01, 0.33, 0.66, 1.01], labels=["Low", "Medium", "High"]
    )
    return out.sort_values("churn_probability", ascending=False)
