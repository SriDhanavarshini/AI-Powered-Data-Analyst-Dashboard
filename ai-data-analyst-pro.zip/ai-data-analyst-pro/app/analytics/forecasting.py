"""
Baseline forecasting: linear-trend + seasonal-naive blend.
Deliberately simple and transparent (per spec: "start with a reliable
baseline, allow future improvement"). Forecasts are explicitly labeled
as predictions, not facts.
"""

import numpy as np
import pandas as pd


def forecast_series(monthly_df: pd.DataFrame, value_col: str, periods: int = 3) -> pd.DataFrame:
    """monthly_df: columns ['month' (YYYY-MM string, sorted), value_col]. Returns forecast rows."""
    df = monthly_df.copy().reset_index(drop=True)
    y = df[value_col].astype(float).values
    x = np.arange(len(y))

    if len(y) < 2:
        last_val = y[-1] if len(y) else 0
        preds = [last_val] * periods
    else:
        # linear trend
        slope, intercept = np.polyfit(x, y, 1)
        trend_preds = intercept + slope * np.arange(len(y), len(y) + periods)
        # blend with last value to avoid runaway trend on short series
        preds = 0.6 * trend_preds + 0.4 * y[-1]
        preds = np.maximum(preds, 0)

    std = y.std() if len(y) > 1 else 0
    last_month = df["month"].iloc[-1] if len(df) else "2026-01"
    year, month = map(int, last_month.split("-"))

    rows = []
    for i, p in enumerate(preds, start=1):
        month += 1
        if month > 12:
            month = 1
            year += 1
        rows.append(
            {
                "month": f"{year}-{month:02d}",
                f"forecast_{value_col}": round(float(p), 2),
                "lower_bound": round(max(0, float(p) - 1.28 * std), 2),
                "upper_bound": round(float(p) + 1.28 * std, 2),
            }
        )
    return pd.DataFrame(rows)
