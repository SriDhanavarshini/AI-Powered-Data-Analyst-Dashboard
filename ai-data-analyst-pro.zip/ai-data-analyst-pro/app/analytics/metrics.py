"""KPI calculations over a pandas DataFrame of orders (used by dashboard + agents)."""

import pandas as pd


def kpi_summary(orders_df: pd.DataFrame) -> dict:
    completed = orders_df[orders_df["order_status"] == "Completed"]
    revenue = completed["revenue"].sum()
    profit = completed["profit"].sum()
    order_count = len(completed)
    aov = revenue / order_count if order_count else 0
    margin = (profit / revenue * 100) if revenue else 0
    return {
        "revenue": round(float(revenue), 2),
        "profit": round(float(profit), 2),
        "orders": int(order_count),
        "aov": round(float(aov), 2),
        "profit_margin_pct": round(float(margin), 2),
    }


def month_over_month(monthly_df: pd.DataFrame, value_col: str) -> pd.DataFrame:
    """monthly_df must have columns ['month', value_col], sorted ascending."""
    df = monthly_df.copy()
    df["mom_change_pct"] = df[value_col].pct_change().round(4) * 100
    return df


def compare_periods(
    orders_df: pd.DataFrame,
    period_col: str,
    period_a,
    period_b,
    value_col: str = "revenue",
) -> dict:
    """Generic driver-comparison helper: compares a metric between two period values
    (e.g. two months) and returns absolute + percentage change."""
    a = orders_df[orders_df[period_col] == period_a][value_col].sum()
    b = orders_df[orders_df[period_col] == period_b][value_col].sum()
    change = a - b
    pct = (change / b * 100) if b else 0
    return {
        "period_a": period_a,
        "period_b": period_b,
        "value_a": round(float(a), 2),
        "value_b": round(float(b), 2),
        "change": round(float(change), 2),
        "change_pct": round(float(pct), 2),
    }
