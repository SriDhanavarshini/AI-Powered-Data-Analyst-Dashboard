"""
Anomaly detection over a daily/monthly time series.
Combines Z-score, IQR, and rolling-mean deviation; flags a point as anomalous
if it trips at least one method, and reports severity + expected vs actual.
"""

import numpy as np
import pandas as pd


def detect_anomalies(
    series_df: pd.DataFrame, date_col: str, value_col: str, z_thresh: float = 2.5
) -> pd.DataFrame:
    df = series_df.sort_values(date_col).reset_index(drop=True).copy()
    values = df[value_col].astype(float)

    mean, std = values.mean(), values.std()
    df["z_score"] = (values - mean) / std if std else 0

    q1, q3 = values.quantile(0.25), values.quantile(0.75)
    iqr = q3 - q1
    lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    df["iqr_flag"] = (values < lower) | (values > upper)

    window = max(3, len(df) // 10)
    rolling_mean = values.rolling(window, min_periods=1, center=True).mean()
    df["expected"] = rolling_mean.round(2)
    df["deviation_pct"] = ((values - rolling_mean) / rolling_mean.replace(0, np.nan) * 100).round(2)

    df["is_anomaly"] = (df["z_score"].abs() > z_thresh) | df["iqr_flag"]
    df["severity"] = np.select(
        [
            df["z_score"].abs() > 4,
            df["z_score"].abs() > 3,
            df["z_score"].abs() > z_thresh,
        ],
        ["high", "medium", "low"],
        default="none",
    )
    return df[df["is_anomaly"]][[date_col, value_col, "expected", "deviation_pct", "severity"]]
