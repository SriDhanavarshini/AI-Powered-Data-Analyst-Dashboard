"""RFM (Recency, Frequency, Monetary) customer segmentation."""

from datetime import datetime

import pandas as pd


def compute_rfm(orders_df: pd.DataFrame, reference_date: datetime | None = None) -> pd.DataFrame:
    df = orders_df[orders_df["order_status"] == "Completed"].copy()
    df["order_date"] = pd.to_datetime(df["order_date"])
    ref = reference_date or df["order_date"].max()

    rfm = (
        df.groupby("customer_id")
        .agg(
            recency=("order_date", lambda x: (ref - x.max()).days),
            frequency=("order_id", "count"),
            monetary=("revenue", "sum"),
        )
        .reset_index()
    )

    rfm["r_score"] = pd.qcut(rfm["recency"], 5, labels=[5, 4, 3, 2, 1], duplicates="drop").astype(
        int
    )
    rfm["f_score"] = pd.qcut(
        rfm["frequency"].rank(method="first"),
        5,
        labels=[1, 2, 3, 4, 5],
        duplicates="drop",
    ).astype(int)
    rfm["m_score"] = pd.qcut(rfm["monetary"], 5, labels=[1, 2, 3, 4, 5], duplicates="drop").astype(
        int
    )
    rfm["rfm_score"] = rfm["r_score"] + rfm["f_score"] + rfm["m_score"]

    def segment(row):
        if row["rfm_score"] >= 13:
            return "VIP"
        if row["rfm_score"] >= 10:
            return "Loyal"
        if row["r_score"] >= 4 and row["f_score"] <= 2:
            return "New"
        if row["r_score"] <= 2 and row["m_score"] >= 4:
            return "At Risk"
        if row["r_score"] <= 2:
            return "Lost"
        return "High Value" if row["m_score"] >= 4 else "Regular"

    rfm["segment"] = rfm.apply(segment, axis=1)
    return rfm
