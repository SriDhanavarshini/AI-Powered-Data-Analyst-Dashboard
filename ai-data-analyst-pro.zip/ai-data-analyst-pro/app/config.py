"""Central configuration loaded from environment variables."""

import os

from dotenv import load_dotenv

load_dotenv()


class Settings:
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./data/processed/analyst.db")
    LLM_API_KEY: str | None = os.getenv("LLM_API_KEY") or None
    LLM_MODEL: str = os.getenv("LLM_MODEL", "gpt-4o-mini")
    API_BASE_URL: str = os.getenv("API_BASE_URL", "http://localhost:8000")
    MAX_QUERY_ROWS: int = 5000
    SQL_TIMEOUT_SECONDS: int = 15

    # LangSmith tracing — if LANGSMITH_API_KEY is set, LangGraph traces every
    # agent run automatically via LangChain's tracing integration. No code
    # changes needed beyond setting these env vars.
    LANGSMITH_API_KEY: str | None = os.getenv("LANGSMITH_API_KEY") or None
    LANGSMITH_PROJECT: str = os.getenv("LANGSMITH_PROJECT", "ai-data-analyst-pro")

    if LANGSMITH_API_KEY:
        os.environ.setdefault("LANGCHAIN_TRACING_V2", "true")
        os.environ.setdefault("LANGCHAIN_API_KEY", LANGSMITH_API_KEY)
        os.environ.setdefault("LANGCHAIN_PROJECT", LANGSMITH_PROJECT)


settings = Settings()
