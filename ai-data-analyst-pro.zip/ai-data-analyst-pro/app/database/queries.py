"""Reusable SQL analytics queries (raw SQL — used by the SQL agent + dashboard)."""

Q_TOTAL_REVENUE = (
    "SELECT ROUND(SUM(revenue), 2) AS total_revenue FROM orders WHERE order_status = 'Completed'"
)
Q_TOTAL_PROFIT = (
    "SELECT ROUND(SUM(profit), 2) AS total_profit FROM orders WHERE order_status = 'Completed'"
)
Q_ORDER_COUNT = "SELECT COUNT(*) AS order_count FROM orders WHERE order_status = 'Completed'"
Q_CUSTOMER_COUNT = "SELECT COUNT(DISTINCT customer_id) AS customer_count FROM customers"
Q_AOV = """
    SELECT ROUND(SUM(revenue) * 1.0 / COUNT(*), 2) AS avg_order_value
    FROM orders WHERE order_status = 'Completed'
"""
Q_PROFIT_MARGIN = """
    SELECT ROUND(SUM(profit) * 100.0 / NULLIF(SUM(revenue), 0), 2) AS profit_margin_pct
    FROM orders WHERE order_status = 'Completed'
"""
Q_MONTHLY_REVENUE = """
    SELECT strftime('%Y-%m', order_date) AS month, ROUND(SUM(revenue), 2) AS revenue
    FROM orders WHERE order_status = 'Completed'
    GROUP BY month ORDER BY month
"""
Q_MONTHLY_PROFIT = """
    SELECT strftime('%Y-%m', order_date) AS month, ROUND(SUM(profit), 2) AS profit
    FROM orders WHERE order_status = 'Completed'
    GROUP BY month ORDER BY month
"""
Q_REGIONAL_PERFORMANCE = """
    SELECT region, ROUND(SUM(revenue), 2) AS revenue, ROUND(SUM(profit), 2) AS profit, COUNT(*) AS orders
    FROM orders WHERE order_status = 'Completed'
    GROUP BY region ORDER BY revenue DESC
"""
Q_CATEGORY_PERFORMANCE = """
    SELECT p.category, ROUND(SUM(o.revenue), 2) AS revenue, ROUND(SUM(o.profit), 2) AS profit, COUNT(*) AS orders
    FROM orders o JOIN products p ON o.product_id = p.product_id
    WHERE o.order_status = 'Completed'
    GROUP BY p.category ORDER BY revenue DESC
"""
Q_TOP_PRODUCTS = """
    SELECT p.product_name, p.category, ROUND(SUM(o.revenue), 2) AS revenue, ROUND(SUM(o.profit), 2) AS profit
    FROM orders o JOIN products p ON o.product_id = p.product_id
    WHERE o.order_status = 'Completed'
    GROUP BY p.product_id ORDER BY revenue DESC LIMIT 10
"""
Q_RETURN_RATE = """
    SELECT ROUND(COUNT(DISTINCT r.order_id) * 100.0 / COUNT(DISTINCT o.order_id), 2) AS return_rate_pct
    FROM orders o LEFT JOIN returns r ON o.order_id = r.order_id
    WHERE o.order_status = 'Completed'
"""
Q_CANCELLATION_RATE = """
    SELECT ROUND(SUM(CASE WHEN order_status = 'Cancelled' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS cancellation_rate_pct
    FROM orders
"""
Q_CUSTOMER_ORDER_HISTORY = """
    SELECT customer_id, order_date, revenue FROM orders WHERE order_status = 'Completed'
"""

# Semantic metadata layer — supplied to the LLM for text-to-SQL grounding
SCHEMA_DESCRIPTION = """
TABLES:
customers(customer_id, name, gender, age, city, state, region, signup_date, customer_segment)
products(product_id, product_name, category, subcategory, price, cost, supplier)
orders(order_id, customer_id, product_id, order_date, quantity, unit_price, discount,
       revenue, cost, profit, region, sales_channel, order_status)
payments(payment_id, order_id, payment_method, payment_status, payment_date)
returns(return_id, order_id, return_date, return_reason, refund_amount)

BUSINESS DEFINITIONS:
- revenue: realized sales amount after discount, before refunds.
- profit: revenue minus cost.
- AOV (average order value): SUM(revenue) / COUNT(orders).
- Only order_status = 'Completed' rows count toward revenue/profit metrics.
- region and category are the primary dimensions for comparisons.

RELATIONSHIPS: orders.customer_id -> customers.customer_id, orders.product_id -> products.product_id,
payments.order_id -> orders.order_id, returns.order_id -> orders.order_id.

ALLOWED OPERATIONS: SELECT and WITH only. No writes.
"""
