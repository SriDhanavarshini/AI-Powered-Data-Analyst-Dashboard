"""SQLAlchemy ORM models — mirrors sql/schema.sql, portable across SQLite/MySQL."""

from datetime import datetime

from sqlalchemy import Column, Date, DateTime, ForeignKey, Integer, Numeric, String, Text
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


class Customer(Base):
    __tablename__ = "customers"
    customer_id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(120), nullable=False)
    gender = Column(String(20))
    age = Column(Integer)
    city = Column(String(80))
    state = Column(String(80))
    region = Column(String(40))
    signup_date = Column(Date)
    customer_segment = Column(String(40))
    orders = relationship("Order", back_populates="customer")


class Product(Base):
    __tablename__ = "products"
    product_id = Column(Integer, primary_key=True, autoincrement=True)
    product_name = Column(String(120), nullable=False)
    category = Column(String(60))
    subcategory = Column(String(60))
    price = Column(Numeric(10, 2))
    cost = Column(Numeric(10, 2))
    supplier = Column(String(80))
    orders = relationship("Order", back_populates="product")


class Order(Base):
    __tablename__ = "orders"
    order_id = Column(Integer, primary_key=True, autoincrement=True)
    customer_id = Column(Integer, ForeignKey("customers.customer_id"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.product_id"), nullable=False)
    order_date = Column(Date, nullable=False)
    quantity = Column(Integer)
    unit_price = Column(Numeric(10, 2))
    discount = Column(Numeric(5, 2))
    revenue = Column(Numeric(12, 2))
    cost = Column(Numeric(12, 2))
    profit = Column(Numeric(12, 2))
    region = Column(String(40))
    sales_channel = Column(String(40))
    order_status = Column(String(30))
    customer = relationship("Customer", back_populates="orders")
    product = relationship("Product", back_populates="orders")


class Payment(Base):
    __tablename__ = "payments"
    payment_id = Column(Integer, primary_key=True, autoincrement=True)
    order_id = Column(Integer, ForeignKey("orders.order_id"), nullable=False)
    payment_method = Column(String(40))
    payment_status = Column(String(30))
    payment_date = Column(Date)
    order = relationship("Order")


class Return(Base):
    __tablename__ = "returns"
    return_id = Column(Integer, primary_key=True, autoincrement=True)
    order_id = Column(Integer, ForeignKey("orders.order_id"), nullable=False)
    return_date = Column(Date)
    return_reason = Column(String(120))
    refund_amount = Column(Numeric(10, 2))
    order = relationship("Order")


class Alert(Base):
    __tablename__ = "alerts"
    alert_id = Column(Integer, primary_key=True, autoincrement=True)
    rule_name = Column(String(80), nullable=False)
    severity = Column(String(20), default="medium")
    message = Column(Text)
    metric_value = Column(Numeric(14, 2))
    threshold_value = Column(Numeric(14, 2))
    triggered_at = Column(DateTime, default=datetime.utcnow)
