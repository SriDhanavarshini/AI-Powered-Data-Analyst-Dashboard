"""
Synthetic e-commerce dataset generator.

Generates realistic customers/products/orders/payments/returns with genuine
seasonal + regional patterns, PLUS intentionally seeded anomalies so the
anomaly-detection and root-cause-analysis layers have real signal to find:

  - A revenue dip in the South region during August (order volume drop)
  - A spike in Electronics returns in November
  - A single extreme outlier day (data-entry-style spike) in March

Usage:
    python -m app.database.seed --customers 2000 --orders 12000
(defaults are smaller than the 10k/50k spec targets so it seeds in seconds
 during development; pass larger values for a fuller dataset)
"""

import argparse
import random
from datetime import date, timedelta

import numpy as np
from faker import Faker

from app.database.connection import SessionLocal, init_db
from app.database.models import Customer, Order, Payment, Product, Return
from app.utils.logger import get_logger

logger = get_logger("seed")
fake = Faker()

REGIONS = ["North", "South", "East", "West"]
STATE_BY_REGION = {
    "North": ["Delhi", "Punjab", "Haryana"],
    "South": ["Tamil Nadu", "Karnataka", "Kerala", "Andhra Pradesh"],
    "East": ["West Bengal", "Odisha", "Bihar"],
    "West": ["Maharashtra", "Gujarat", "Rajasthan"],
}
CITY_BY_STATE = {
    "Delhi": ["New Delhi"],
    "Punjab": ["Ludhiana", "Amritsar"],
    "Haryana": ["Gurgaon", "Faridabad"],
    "Tamil Nadu": ["Chennai", "Coimbatore"],
    "Karnataka": ["Bangalore", "Mysore"],
    "Kerala": ["Kochi", "Trivandrum"],
    "Andhra Pradesh": ["Vizag", "Vijayawada"],
    "West Bengal": ["Kolkata", "Howrah"],
    "Odisha": ["Bhubaneswar"],
    "Bihar": ["Patna"],
    "Maharashtra": ["Mumbai", "Pune"],
    "Gujarat": ["Ahmedabad", "Surat"],
    "Rajasthan": ["Jaipur"],
}
SEGMENTS = ["Regular", "Premium", "Budget"]
CATEGORIES = {
    "Electronics": ["Phones", "Laptops", "Accessories"],
    "Fashion": ["Menswear", "Womenswear", "Footwear"],
    "Home": ["Furniture", "Kitchen", "Decor"],
    "Beauty": ["Skincare", "Haircare"],
    "Sports": ["Fitness", "Outdoor"],
}
CHANNELS = ["Web", "Mobile App", "Marketplace"]
STATUSES = ["Completed", "Completed", "Completed", "Cancelled"]
RETURN_REASONS = [
    "Defective",
    "Wrong item",
    "No longer needed",
    "Better price found",
    "Late delivery",
]


def gen_customers(n: int) -> list[Customer]:
    customers = []
    for _ in range(n):
        region = random.choice(REGIONS)
        state = random.choice(STATE_BY_REGION[region])
        city = random.choice(CITY_BY_STATE[state])
        customers.append(
            Customer(
                name=fake.name(),
                gender=random.choice(["Male", "Female"]),
                age=random.randint(18, 65),
                city=city,
                state=state,
                region=region,
                signup_date=fake.date_between(start_date="-3y", end_date="-30d"),
                customer_segment=random.choices(SEGMENTS, weights=[0.6, 0.25, 0.15])[0],
            )
        )
    return customers


def gen_products(n: int) -> list[Product]:
    products = []
    for _ in range(n):
        category = random.choice(list(CATEGORIES.keys()))
        subcat = random.choice(CATEGORIES[category])
        cost = round(random.uniform(200, 8000), 2)
        price = round(cost * random.uniform(1.2, 2.2), 2)
        products.append(
            Product(
                product_name=f"{subcat} {fake.word().capitalize()} {random.randint(100,999)}",
                category=category,
                subcategory=subcat,
                price=price,
                cost=cost,
                supplier=fake.company(),
            )
        )
    return products


def seasonal_multiplier(d: date) -> float:
    """Nov/Dec festive + sale season boost, mild summer dip."""
    if d.month in (11, 12):
        return 1.4
    if d.month in (5, 6):
        return 0.85
    return 1.0


def gen_orders(
    n: int, customers: list[Customer], products: list[Product]
) -> tuple[list[Order], list[Payment], list[Return]]:
    orders, payments, returns = [], [], []
    start = date.today() - timedelta(days=730)

    for i in range(n):
        cust = random.choice(customers)
        prod = random.choice(products)
        order_date = start + timedelta(days=random.randint(0, 729))

        mult = seasonal_multiplier(order_date)

        # --- seeded anomaly 1: South region revenue dip in August (order volume drop) ---
        if cust.region == "South" and order_date.month == 8 and random.random() < 0.55:
            continue  # simulate ~55% fewer South orders in August

        quantity = max(1, int(np.random.poisson(2) * mult))
        discount = round(random.choice([0, 0, 0, 5, 10, 15, 20]), 2)
        unit_price = float(prod.price)
        revenue = round(quantity * unit_price * (1 - discount / 100), 2)
        cost = round(quantity * float(prod.cost), 2)

        # --- seeded anomaly 3: one extreme outlier day in March (data-entry-style spike) ---
        if order_date.month == 3 and order_date.day == 15 and random.random() < 0.02:
            revenue *= 12

        profit = round(revenue - cost, 2)
        status = random.choices(STATUSES, weights=[0.85, 0.05, 0.05, 0.05])[0]

        order = Order(
            customer_id=None,
            product_id=None,  # set after flush via relationship
            order_date=order_date,
            quantity=quantity,
            unit_price=unit_price,
            discount=discount,
            revenue=revenue,
            cost=cost,
            profit=profit,
            region=cust.region,
            sales_channel=random.choice(CHANNELS),
            order_status=status,
        )
        order.customer = cust
        order.product = prod
        orders.append(order)

        payments.append(
            Payment(
                order=order,
                payment_method=random.choice(["Card", "UPI", "Net Banking", "COD"]),
                payment_status="Success" if status != "Cancelled" else "Refunded",
                payment_date=order_date,
            )
        )

        # --- seeded anomaly 2: Electronics return-rate spike in November ---
        return_prob = 0.04
        if prod.category == "Electronics" and order_date.month == 11:
            return_prob = 0.22
        if random.random() < return_prob and status == "Completed":
            returns.append(
                Return(
                    order=order,
                    return_date=order_date + timedelta(days=random.randint(2, 20)),
                    return_reason=random.choice(RETURN_REASONS),
                    refund_amount=revenue,
                )
            )

    return orders, payments, returns


def run(n_customers: int, n_products: int, n_orders: int) -> None:
    init_db()
    db = SessionLocal()
    try:
        logger.info(
            f"Generating {n_customers} customers, {n_products} products, {n_orders} orders..."
        )
        customers = gen_customers(n_customers)
        products = gen_products(n_products)
        db.add_all(customers)
        db.add_all(products)
        db.flush()

        orders, payments, returns = gen_orders(n_orders, customers, products)
        db.add_all(orders)
        db.flush()
        db.add_all(payments)
        db.add_all(returns)
        db.commit()
        logger.info(
            f"Seeded {len(customers)} customers, {len(products)} products, "
            f"{len(orders)} orders, {len(payments)} payments, {len(returns)} returns."
        )
    finally:
        db.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--customers", type=int, default=2000)
    parser.add_argument("--products", type=int, default=150)
    parser.add_argument("--orders", type=int, default=12000)
    args = parser.parse_args()
    run(args.customers, args.products, args.orders)
