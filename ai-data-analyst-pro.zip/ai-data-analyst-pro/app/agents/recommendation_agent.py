"""Turns analysis results into a structured Finding / Evidence / Driver / Recommendation."""


def build_recommendation(
    finding: str, evidence: str, driver: str, recommendation: str, impact: str
) -> dict:
    return {
        "finding": finding,
        "evidence": evidence,
        "possible_driver": driver,
        "recommendation": recommendation,
        "expected_impact": impact,
    }


def recommend_from_regional_gap(region_df) -> dict | None:
    """region_df: columns [region, revenue, profit, orders], sorted desc by revenue."""
    if region_df is None or len(region_df) < 2:
        return None
    top, bottom = region_df.iloc[0], region_df.iloc[-1]
    gap_pct = round((top["revenue"] - bottom["revenue"]) / top["revenue"] * 100, 1)
    if gap_pct < 20:
        return None
    return build_recommendation(
        finding=f"{bottom['region']} generates {gap_pct}% less revenue than {top['region']}, the top region.",
        evidence=f"{top['region']}: ₹{top['revenue']:,.0f} revenue vs {bottom['region']}: ₹{bottom['revenue']:,.0f}.",
        driver=f"Lower order volume or weaker product mix in {bottom['region']} (correlation observed, not confirmed cause).",
        recommendation=f"Investigate demand and marketing spend in {bottom['region']}; consider a regional promotion.",
        impact=f"Closing even half the gap could add meaningful revenue from {bottom['region']}.",
    )
