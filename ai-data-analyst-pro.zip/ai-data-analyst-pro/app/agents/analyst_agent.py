"""
AI Analyst orchestrator — built on LangGraph.

Each intent (forecast, anomaly, root_cause, recommendation, what_if,
sql_lookup) is a graph node. A router node classifies intent and picks the
next node via a conditional edge, so the graph only ever calls the tools a
given question actually needs.

Conversational memory: `context` (passed in from the API/session layer)
carries the last resolved metric, region table, and category table. A
resolve_context node runs before classification and lets follow-ups like
"why did it decrease" or "which region caused it" reuse what was already
computed, instead of treating every question as brand new. Each response
returns an updated `context` for the caller to persist and pass into the
next turn.

If LANGSMITH_API_KEY / LANGCHAIN_TRACING_V2 are set in the environment,
every graph run is traced automatically by LangGraph's LangChain
integration -- no code changes needed here.
"""

from typing import Any, TypedDict

import pandas as pd
from langgraph.graph import END, StateGraph

from app.agents.recommendation_agent import recommend_from_regional_gap
from app.agents.sql_agent import answer_with_sql
from app.analytics.anomaly import detect_anomalies
from app.analytics.forecasting import forecast_series
from app.database import queries as Q
from app.tools.sql_tool import run_sql
from app.utils.logger import get_logger

logger = get_logger("analyst_agent")


class AgentState(TypedDict, total=False):
    question: str
    context: dict[str, Any]
    intent: str
    reused_from_memory: bool
    result: dict[str, Any]


# ---------------------------------------------------------------------------
# Intent classification + conversational-memory resolution
# ---------------------------------------------------------------------------


def classify_intent(question: str) -> str:
    q = question.lower()
    if any(w in q for w in ["forecast", "predict", "next month", "next 3 months", "next 7 days"]):
        return "forecast"
    if any(w in q for w in ["anomaly", "unusual", "abnormal", "outlier"]):
        return "anomaly"
    if any(w in q for w in ["why did", "why is", "root cause", "caused it", "which region caused"]):
        return "root_cause"
    if any(w in q for w in ["recommend", "improve", "suggestion"]):
        return "recommendation"
    if any(w in q for w in ["what if", "scenario", "increase by", "decrease by"]):
        return "what_if"
    return "sql_lookup"


def resolve_node(state: AgentState) -> AgentState:
    """Runs before classification. Detects pronoun-style follow-ups
    ("it", "that", "which region caused it") and flags whether this turn
    can be answered from memory (`context`) instead of recomputing."""
    question = state["question"]
    context = state.get("context") or {}
    q = question.lower()

    reused = False
    if "which region" in q and context.get("last_region_table"):
        reused = True
    if ("why did it" in q or "why is it" in q) and context.get("last_metric"):
        reused = True

    return {**state, "context": context, "reused_from_memory": reused}


def router_node(state: AgentState) -> AgentState:
    intent = classify_intent(state["question"])
    logger.info(
        f"intent={intent} question={state['question']!r} reused={state.get('reused_from_memory')}"
    )
    return {**state, "intent": intent}


def route_decision(state: AgentState) -> str:
    return state["intent"]


# ---------------------------------------------------------------------------
# Tool nodes -- one per intent
# ---------------------------------------------------------------------------


def forecast_node(state: AgentState) -> AgentState:
    monthly = run_sql(Q.Q_MONTHLY_REVENUE)
    fc = forecast_series(monthly, "revenue", periods=3)
    chart_df = pd.concat(
        [
            monthly.rename(columns={"revenue": "value"}),
            fc.rename(columns={"forecast_revenue": "value"})[["month", "value"]],
        ]
    )
    result = {
        "intent": "forecast",
        "answer": "Forecast (predicted values, not guaranteed) for the next 3 months of revenue.",
        "table": fc.to_dict(orient="records"),
        "chart_table": chart_df.to_dict(orient="records"),
    }
    context = {**state["context"], "last_metric": "revenue"}
    return {**state, "result": result, "context": context}


def anomaly_node(state: AgentState) -> AgentState:
    monthly = run_sql(Q.Q_MONTHLY_REVENUE)
    anomalies = detect_anomalies(monthly, "month", "revenue")
    if anomalies.empty:
        answer = "No significant anomalies detected in monthly revenue."
    else:
        rows = anomalies.to_dict(orient="records")
        answer = f"Found {len(rows)} anomalous month(s): " + "; ".join(
            f"{r['month']} was {r['deviation_pct']}% off the expected trend (severity: {r['severity']})"
            for r in rows
        )
    result = {"intent": "anomaly", "answer": answer, "table": anomalies.to_dict(orient="records")}
    context = {**state["context"], "last_metric": "revenue"}
    return {**state, "result": result, "context": context}


def root_cause_node(state: AgentState) -> AgentState:
    context = state["context"]

    if state.get("reused_from_memory") and context.get("last_region_table"):
        region_df = pd.DataFrame(context["last_region_table"])
        category_df = pd.DataFrame(context.get("last_category_table", []))
        note = "Reusing the region/category breakdown from your previous question. "
    else:
        region_df = run_sql(Q.Q_REGIONAL_PERFORMANCE)
        category_df = run_sql(Q.Q_CATEGORY_PERFORMANCE)
        note = ""

    rec = recommend_from_regional_gap(region_df)
    answer = (
        note
        + "Root-cause view across regions and categories (observed correlations, not confirmed causes)."
    )
    result = {
        "intent": "root_cause",
        "answer": answer,
        "region_table": region_df.to_dict(orient="records"),
        "category_table": category_df.to_dict(orient="records"),
        "recommendation": rec,
    }
    new_context = {
        **context,
        "last_metric": "revenue",
        "last_region_table": region_df.to_dict(orient="records"),
        "last_category_table": category_df.to_dict(orient="records"),
    }
    return {**state, "result": result, "context": new_context}


def recommendation_node(state: AgentState) -> AgentState:
    region_df = run_sql(Q.Q_REGIONAL_PERFORMANCE)
    rec = recommend_from_regional_gap(region_df)
    result = {
        "intent": "recommendation",
        "answer": "Recommendation based on current data.",
        "recommendation": rec,
    }
    context = {**state["context"], "last_region_table": region_df.to_dict(orient="records")}
    return {**state, "result": result, "context": context}


def what_if_node(state: AgentState) -> AgentState:
    question = state["question"]
    base = run_sql(Q.Q_TOTAL_REVENUE).iloc[0, 0] or 0
    pct = 10
    for token in question.replace("%", "").split():
        if token.replace(".", "", 1).isdigit():
            pct = float(token)
            break
    scenario = round(base * (1 + pct / 100), 2)
    result = {
        "intent": "what_if",
        "answer": f"Scenario simulation (not a guaranteed prediction): a {pct}% change in sales.",
        "current_revenue": round(float(base), 2),
        "scenario_revenue": scenario,
        "difference": round(scenario - float(base), 2),
        "change_pct": pct,
    }
    context = {**state["context"], "last_metric": "revenue"}
    return {**state, "result": result, "context": context}


def sql_lookup_node(state: AgentState) -> AgentState:
    question = state["question"]
    sql_result = answer_with_sql(question)
    df = sql_result["df"]
    answer = (
        "I don't have enough data to answer that reliably."
        if df.empty
        else f"Query returned {len(df)} row(s)."
    )
    result = {
        "intent": "sql_lookup",
        "answer": answer,
        "sql": sql_result["sql"],
        "table": df.to_dict(orient="records"),
        "source": sql_result["source"],
    }
    context = {**state["context"]}
    if not df.empty and len(df.columns) == 1:
        context["last_metric"] = df.columns[0]
    return {**state, "result": result, "context": context}


# ---------------------------------------------------------------------------
# Build the graph
# ---------------------------------------------------------------------------

_graph = StateGraph(AgentState)
_graph.add_node("resolve", resolve_node)
_graph.add_node("router", router_node)
_graph.add_node("forecast", forecast_node)
_graph.add_node("anomaly", anomaly_node)
_graph.add_node("root_cause", root_cause_node)
_graph.add_node("recommendation", recommendation_node)
_graph.add_node("what_if", what_if_node)
_graph.add_node("sql_lookup", sql_lookup_node)

_graph.set_entry_point("resolve")
_graph.add_edge("resolve", "router")
_graph.add_conditional_edges(
    "router",
    route_decision,
    {
        "forecast": "forecast",
        "anomaly": "anomaly",
        "root_cause": "root_cause",
        "recommendation": "recommendation",
        "what_if": "what_if",
        "sql_lookup": "sql_lookup",
    },
)
for node in ("forecast", "anomaly", "root_cause", "recommendation", "what_if", "sql_lookup"):
    _graph.add_edge(node, END)

compiled_graph = _graph.compile()


def handle_question(question: str, context: dict | None = None) -> dict:
    """Runs the LangGraph agent for one question. Returns the result dict
    plus an updated `context` -- persist and pass this back in on the next
    turn to enable follow-up questions."""
    final_state = compiled_graph.invoke({"question": question, "context": context or {}})
    result = final_state["result"]
    result["context"] = final_state["context"]
    return result
