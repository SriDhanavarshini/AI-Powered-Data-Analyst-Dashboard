"""
Text-to-SQL agent.

If LLM_API_KEY is set, asks the LLM to generate SQL grounded in the semantic
schema layer, then runs it through validate_sql before execution.

If no key is set, falls back to a small library of pre-defined, parameterized
queries (app/database/queries.py) selected by keyword matching — this keeps
the whole app runnable and demonstrable with zero API cost/setup.
"""

from app.config import settings
from app.database import queries as Q
from app.tools.sql_tool import run_sql
from app.utils.logger import get_logger
from app.validation.sql_validator import SQLValidationError

logger = get_logger("sql_agent")

FALLBACK_MAP = {
    "revenue": Q.Q_TOTAL_REVENUE,
    "profit": Q.Q_TOTAL_PROFIT,
    "orders": Q.Q_ORDER_COUNT,
    "customers": Q.Q_CUSTOMER_COUNT,
    "average order": Q.Q_AOV,
    "aov": Q.Q_AOV,
    "margin": Q.Q_PROFIT_MARGIN,
    "monthly revenue": Q.Q_MONTHLY_REVENUE,
    "region": Q.Q_REGIONAL_PERFORMANCE,
    "category": Q.Q_CATEGORY_PERFORMANCE,
    "top product": Q.Q_TOP_PRODUCTS,
    "return": Q.Q_RETURN_RATE,
    "cancel": Q.Q_CANCELLATION_RATE,
}


def _llm_generate_sql(question: str) -> str:
    from openai import OpenAI

    client = OpenAI(api_key=settings.LLM_API_KEY)
    prompt = f"""You are a SQL generator for a SQLite analytics database.

{Q.SCHEMA_DESCRIPTION}

Generate ONE read-only SQL query (SELECT or WITH only) that answers this question.
Return ONLY the raw SQL, no markdown, no explanation.

Question: {question}"""
    resp = client.chat.completions.create(
        model=settings.LLM_MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0,
    )
    sql = resp.choices[0].message.content.strip()
    return sql.strip("`").replace("sql\n", "", 1) if sql.startswith("```") else sql


def answer_with_sql(question: str) -> dict:
    """Returns {'sql': str, 'df': DataFrame, 'source': 'llm'|'fallback'}."""
    if settings.LLM_API_KEY:
        try:
            sql = _llm_generate_sql(question)
            df = run_sql(sql)
            return {"sql": sql, "df": df, "source": "llm"}
        except (SQLValidationError, Exception) as e:
            logger.warning(f"LLM SQL generation/execution failed, falling back: {e}")

    q_lower = question.lower()
    for keyword, sql in FALLBACK_MAP.items():
        if keyword in q_lower:
            df = run_sql(sql)
            return {"sql": sql, "df": df, "source": "fallback"}

    # default: overall KPI snapshot
    df = run_sql(Q.Q_TOTAL_REVENUE)
    return {"sql": Q.Q_TOTAL_REVENUE, "df": df, "source": "fallback_default"}
