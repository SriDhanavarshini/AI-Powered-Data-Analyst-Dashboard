"""API routes."""

import tempfile

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel

from app.agents.analyst_agent import handle_question
from app.alerts.rules import evaluate_all_rules
from app.analytics.churn import (
    build_churn_features,
    predict_churn_risk,
    train_churn_model,
)
from app.analytics.metrics import kpi_summary
from app.analytics.rfm import compute_rfm
from app.database import queries as Q
from app.database.connection import SessionLocal
from app.database.models import Alert
from app.reports.report_builder import build_report_data, export_csv, export_excel, export_pdf
from app.tools.sql_tool import run_sql
from app.utils.logger import get_logger, new_request_id
from app.validation.data_validator import data_quality_report

router = APIRouter()
logger = get_logger("api")


class QuestionRequest(BaseModel):
    question: str
    context: dict | None = None


@router.post("/ask")
def ask(req: QuestionRequest):
    rid = new_request_id()
    logger.info(f"[{rid}] question={req.question!r}")
    try:
        result = handle_question(req.question, req.context)
        result["request_id"] = rid
        return result
    except Exception as e:
        logger.error(f"[{rid}] error={e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/kpis")
def kpis():
    df = run_sql("SELECT * FROM orders")
    return kpi_summary(df)


@router.get("/regional-performance")
def regional_performance():
    return run_sql(Q.Q_REGIONAL_PERFORMANCE).to_dict(orient="records")


@router.get("/category-performance")
def category_performance():
    return run_sql(Q.Q_CATEGORY_PERFORMANCE).to_dict(orient="records")


@router.get("/monthly-revenue")
def monthly_revenue():
    return run_sql(Q.Q_MONTHLY_REVENUE).to_dict(orient="records")


@router.get("/top-products")
def top_products():
    return run_sql(Q.Q_TOP_PRODUCTS).to_dict(orient="records")


@router.get("/customer-segments")
def customer_segments():
    df = run_sql("SELECT * FROM orders")
    rfm = compute_rfm(df)
    return rfm["segment"].value_counts().to_dict()


@router.get("/churn-risk")
def churn_risk(top_n: int = 20):
    df = run_sql("SELECT * FROM orders")
    features = build_churn_features(df)
    model, accuracy = train_churn_model(features)
    if model is None:
        return {"error": "Not enough data yet to train a churn model.", "customers": []}
    risk = predict_churn_risk(model, features)
    return {
        "model_accuracy": accuracy,
        "customers": risk.head(top_n).to_dict(orient="records"),
    }


@router.get("/data-quality")
def data_quality():
    df = run_sql("SELECT * FROM orders")
    return data_quality_report(df)


# ---------------------------------------------------------------------------
# Alerts
# ---------------------------------------------------------------------------


@router.post("/alerts/check")
def run_alert_check():
    """Manually triggers an alert-rule evaluation (also runs automatically
    every 6 hours via the scheduler in main.py)."""
    triggered = evaluate_all_rules()
    return {"triggered_count": len(triggered), "triggered": triggered}


@router.get("/alerts/history")
def alert_history(limit: int = 50):
    db = SessionLocal()
    try:
        alerts = db.query(Alert).order_by(Alert.triggered_at.desc()).limit(limit).all()
        return [
            {
                "alert_id": a.alert_id,
                "rule_name": a.rule_name,
                "severity": a.severity,
                "message": a.message,
                "metric_value": float(a.metric_value) if a.metric_value is not None else None,
                "threshold_value": (
                    float(a.threshold_value) if a.threshold_value is not None else None
                ),
                "triggered_at": a.triggered_at.isoformat() if a.triggered_at else None,
            }
            for a in alerts
        ]
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------


@router.get("/reports/{period}")
def get_report_data(period: str):
    if period not in ("daily", "weekly", "monthly"):
        raise HTTPException(status_code=400, detail="period must be daily, weekly, or monthly")
    return build_report_data(period)


@router.get("/reports/{period}/export/{fmt}")
def export_report(period: str, fmt: str):
    if period not in ("daily", "weekly", "monthly"):
        raise HTTPException(status_code=400, detail="period must be daily, weekly, or monthly")
    if fmt not in ("pdf", "xlsx", "csv"):
        raise HTTPException(status_code=400, detail="fmt must be pdf, xlsx, or csv")

    report = build_report_data(period)
    suffix = f".{fmt}"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        path = tmp.name

    if fmt == "pdf":
        export_pdf(report, path)
        media_type = "application/pdf"
    elif fmt == "xlsx":
        export_excel(report, path)
        media_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    else:
        export_csv(report, path)
        media_type = "text/csv"

    filename = f"{period}_report.{fmt}"
    return FileResponse(path, media_type=media_type, filename=filename)
