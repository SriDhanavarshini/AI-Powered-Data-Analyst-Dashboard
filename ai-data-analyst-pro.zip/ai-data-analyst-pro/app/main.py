"""FastAPI application entrypoint."""

from apscheduler.schedulers.background import BackgroundScheduler
from fastapi import FastAPI

from app.alerts.rules import evaluate_all_rules
from app.api.routes import router
from app.database.connection import init_db
from app.utils.logger import get_logger

logger = get_logger("main")

app = FastAPI(title="AI Data Analyst Pro", version="0.1.0")
app.include_router(router, prefix="/api")

scheduler = BackgroundScheduler()


@app.on_event("startup")
def on_startup():
    init_db()
    # Evaluate alert rules every 6 hours. In a real deployment this cadence
    # should match how often the underlying data actually refreshes.
    scheduler.add_job(evaluate_all_rules, "interval", hours=6, id="alert_check")
    scheduler.start()
    logger.info("Database initialized. Alert scheduler started. API ready.")


@app.on_event("shutdown")
def on_shutdown():
    scheduler.shutdown()


@app.get("/")
def root():
    return {"status": "ok", "service": "AI Data Analyst Pro"}
