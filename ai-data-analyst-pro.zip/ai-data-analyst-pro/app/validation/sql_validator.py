"""
SQL safety validator. This is the security boundary between the LLM and the
database — LLM-generated SQL must pass through here before execution.

Allows: SELECT, WITH
Rejects: DROP, DELETE, UPDATE, INSERT, ALTER, TRUNCATE, CREATE, and any
multi-statement input (semicolon-separated stacking).
"""

import sqlparse

FORBIDDEN_KEYWORDS = {
    "DROP",
    "DELETE",
    "UPDATE",
    "INSERT",
    "ALTER",
    "TRUNCATE",
    "CREATE",
    "GRANT",
    "REVOKE",
    "REPLACE",
    "ATTACH",
    "DETACH",
}


class SQLValidationError(Exception):
    pass


def validate_sql(sql: str, max_rows: int = 5000) -> str:
    """Raises SQLValidationError if unsafe. Returns the (possibly row-limited) SQL if safe."""
    if not sql or not sql.strip():
        raise SQLValidationError("Empty SQL.")

    statements = [s for s in sqlparse.split(sql) if s.strip()]
    if len(statements) != 1:
        raise SQLValidationError("Only a single SQL statement is allowed.")

    stmt = statements[0]
    parsed = sqlparse.parse(stmt)[0]
    stmt_type = parsed.get_type()  # SELECT, INSERT, UNKNOWN, ...

    upper = stmt.upper()
    for kw in FORBIDDEN_KEYWORDS:
        if kw in upper.split():
            raise SQLValidationError(f"Forbidden keyword detected: {kw}")

    if stmt_type not in ("SELECT", "UNKNOWN"):  # WITH ... often parses as UNKNOWN
        raise SQLValidationError(f"Only SELECT/WITH statements are allowed, got: {stmt_type}")

    stripped = stmt.strip().upper()
    if not stripped.startswith(("SELECT", "WITH")):
        raise SQLValidationError("Statement must start with SELECT or WITH.")

    if "LIMIT" not in upper:
        stmt = stmt.rstrip().rstrip(";") + f" LIMIT {max_rows}"

    return stmt
