"""Data quality checks over the orders/customers tables."""

import pandas as pd


def data_quality_report(orders_df: pd.DataFrame) -> dict:
    total = len(orders_df)
    if total == 0:
        return {"row_count": 0, "quality_score": 0.0}

    missing = orders_df.isna().sum().sum()
    missing_pct = round(missing / (total * len(orders_df.columns)) * 100, 2)

    duplicate_pct = round(orders_df.duplicated().sum() / total * 100, 2)

    invalid_revenue = ((orders_df["revenue"] < 0) | orders_df["revenue"].isna()).sum()
    invalid_pct = round(invalid_revenue / total * 100, 2)

    quality_score = round(100 - missing_pct - duplicate_pct - invalid_pct, 2)
    quality_score = max(0.0, min(100.0, quality_score))

    return {
        "row_count": total,
        "missing_values_pct": missing_pct,
        "duplicates_pct": duplicate_pct,
        "invalid_records_pct": invalid_pct,
        "quality_score": quality_score,
    }
