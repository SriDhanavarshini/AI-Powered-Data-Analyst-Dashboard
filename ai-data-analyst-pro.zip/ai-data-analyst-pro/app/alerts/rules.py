"""
Configurable alert rules, evaluated against current data.

Each rule function returns an alert dict if it trips, or None otherwise.
`evaluate_all_rules()` runs every rule and persists any that trip.
"""

from app.database import queries as Q
from app.database.connection import SessionLocal
from app.database.models import Alert
from app.tools.sql_tool import run_sql
from app.utils.logger import get_logger

logger = get_logger("alerts")

REVENUE_DROP_THRESHOLD_PCT = 10.0
MARGIN_FLOOR_PCT = 15.0
RETURN_RATE_CEILING_PCT = 15.0


def check_revenue_drop() -> dict | None:
    monthly = run_sql(Q.Q_MONTHLY_REVENUE)
    if len(monthly) < 2:
        return None
    latest, previous = monthly.iloc[-1], monthly.iloc[-2]
    if previous["revenue"] == 0:
        return None
    change_pct = (latest["revenue"] - previous["revenue"]) / previous["revenue"] * 100
    if change_pct <= -REVENUE_DROP_THRESHOLD_PCT:
        return {
            "rule_name": "revenue_drop",
            "severity": "high" if change_pct <= -20 else "medium",
            "message": f"Revenue dropped {abs(round(change_pct, 1))}% in {latest['month']} vs {previous['month']}.",
            "metric_value": round(float(latest["revenue"]), 2),
            "threshold_value": REVENUE_DROP_THRESHOLD_PCT,
        }
    return None


def check_profit_margin() -> dict | None:
    result = run_sql(Q.Q_PROFIT_MARGIN)
    if result.empty:
        return None
    margin = result.iloc[0, 0] or 0
    if margin < MARGIN_FLOOR_PCT:
        return {
            "rule_name": "low_profit_margin",
            "severity": "medium",
            "message": f"Profit margin is {margin}%, below the {MARGIN_FLOOR_PCT}% floor.",
            "metric_value": round(float(margin), 2),
            "threshold_value": MARGIN_FLOOR_PCT,
        }
    return None


def check_return_rate() -> dict | None:
    result = run_sql(Q.Q_RETURN_RATE)
    if result.empty:
        return None
    rate = result.iloc[0, 0] or 0
    if rate > RETURN_RATE_CEILING_PCT:
        return {
            "rule_name": "high_return_rate",
            "severity": "medium",
            "message": f"Return rate is {rate}%, above the {RETURN_RATE_CEILING_PCT}% ceiling.",
            "metric_value": round(float(rate), 2),
            "threshold_value": RETURN_RATE_CEILING_PCT,
        }
    return None


ALL_RULES = [check_revenue_drop, check_profit_margin, check_return_rate]


def evaluate_all_rules() -> list[dict]:
    """Runs every rule; persists and returns any that trip."""
    triggered = []
    db = SessionLocal()
    try:
        for rule_fn in ALL_RULES:
            try:
                result = rule_fn()
            except Exception as e:
                logger.error(f"Alert rule {rule_fn.__name__} failed: {e}")
                continue
            if result:
                alert = Alert(**result)
                db.add(alert)
                triggered.append(result)
                logger.info(f"ALERT TRIGGERED: {result['rule_name']} — {result['message']}")
        db.commit()
    finally:
        db.close()
    return triggered
