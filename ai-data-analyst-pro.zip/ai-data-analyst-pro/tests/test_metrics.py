import pandas as pd

from app.analytics.metrics import compare_periods, kpi_summary


def sample_orders():
    return pd.DataFrame(
        [
            {"order_status": "Completed", "revenue": 100, "profit": 20},
            {"order_status": "Completed", "revenue": 200, "profit": 50},
            {"order_status": "Cancelled", "revenue": 999, "profit": 999},
        ]
    )


def test_kpi_summary_excludes_cancelled():
    result = kpi_summary(sample_orders())
    assert result["revenue"] == 300
    assert result["orders"] == 2


def test_compare_periods():
    df = pd.DataFrame(
        [
            {"month": "2026-01", "revenue": 100},
            {"month": "2026-02", "revenue": 80},
        ]
    )
    result = compare_periods(df, "month", "2026-02", "2026-01", "revenue")
    assert result["change"] == -20
    assert result["change_pct"] == -20.0
