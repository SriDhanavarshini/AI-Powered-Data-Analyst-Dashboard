from app.agents.analyst_agent import classify_intent


def test_classifies_forecast():
    assert classify_intent("Forecast revenue for next 3 months") == "forecast"


def test_classifies_anomaly():
    assert classify_intent("Find unusual sales behavior") == "anomaly"


def test_classifies_root_cause():
    assert classify_intent("Why did revenue decrease in August?") == "root_cause"


def test_classifies_what_if():
    assert classify_intent("What happens if sales increase by 10%?") == "what_if"


def test_classifies_recommendation():
    assert classify_intent("Give me recommendations to improve revenue") == "recommendation"


def test_defaults_to_sql_lookup():
    assert classify_intent("What was total revenue?") == "sql_lookup"
