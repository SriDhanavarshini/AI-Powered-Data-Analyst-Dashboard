import pandas as pd

from app.analytics.anomaly import detect_anomalies


def test_detects_obvious_spike():
    df = pd.DataFrame(
        {
            "month": [f"2026-{i:02d}" for i in range(1, 11)],
            "revenue": [100, 105, 98, 102, 99, 101, 5000, 103, 97, 100],
        }
    )
    anomalies = detect_anomalies(df, "month", "revenue")
    assert "2026-07" in anomalies["month"].values
