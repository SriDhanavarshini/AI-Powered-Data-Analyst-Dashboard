import pytest

from app.validation.sql_validator import SQLValidationError, validate_sql


def test_allows_select():
    result = validate_sql("SELECT * FROM orders")
    assert result.upper().startswith("SELECT")


def test_allows_with():
    result = validate_sql("WITH x AS (SELECT 1) SELECT * FROM x")
    assert "SELECT" in result.upper()


def test_rejects_drop():
    with pytest.raises(SQLValidationError):
        validate_sql("DROP TABLE orders")


def test_rejects_delete():
    with pytest.raises(SQLValidationError):
        validate_sql("DELETE FROM orders WHERE order_id = 1")


def test_rejects_multi_statement():
    with pytest.raises(SQLValidationError):
        validate_sql("SELECT 1; DROP TABLE orders;")


def test_adds_limit_when_missing():
    result = validate_sql("SELECT * FROM orders", max_rows=100)
    assert "LIMIT 100" in result.upper()
