from unittest.mock import patch

import pandas as pd

from app.alerts.rules import check_profit_margin, check_revenue_drop


def test_revenue_drop_triggers_below_threshold():
    monthly = pd.DataFrame({"month": ["2026-07", "2026-08"], "revenue": [1000, 700]})
    with patch("app.alerts.rules.run_sql", return_value=monthly):
        result = check_revenue_drop()
    assert result is not None
    assert result["rule_name"] == "revenue_drop"


def test_revenue_drop_silent_when_stable():
    monthly = pd.DataFrame({"month": ["2026-07", "2026-08"], "revenue": [1000, 980]})
    with patch("app.alerts.rules.run_sql", return_value=monthly):
        result = check_revenue_drop()
    assert result is None


def test_margin_triggers_below_floor():
    margin_df = pd.DataFrame({"profit_margin_pct": [10.0]})
    with patch("app.alerts.rules.run_sql", return_value=margin_df):
        result = check_profit_margin()
    assert result is not None
    assert result["rule_name"] == "low_profit_margin"
