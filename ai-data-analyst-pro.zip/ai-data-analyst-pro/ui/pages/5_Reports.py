"""Automated reports page — daily/weekly/monthly, exportable to PDF/Excel/CSV."""
import requests
import streamlit as st
import pandas as pd
import os

API = os.getenv("API_BASE_URL", "http://localhost:8000")
st.set_page_config(page_title="Reports", layout="wide")
st.title("Automated Reports")

period = st.selectbox("Report period", ["daily", "weekly", "monthly"], index=2)

if st.button("Generate report"):
    with st.spinner("Building report..."):
        report = requests.get(f"{API}/api/reports/{period}", timeout=20).json()
        st.session_state["report"] = report

if "report" in st.session_state:
    report = st.session_state["report"]
    kpis = report["kpis"]

    st.caption(f"Generated: {report['generated_at']}")
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Revenue", f"₹{kpis['revenue']:,.0f}")
    c2.metric("Profit", f"₹{kpis['profit']:,.0f}")
    c3.metric("Orders", f"{kpis['orders']:,}")
    c4.metric("AOV", f"₹{kpis['aov']:,.0f}")
    c5.metric("Margin", f"{kpis['profit_margin_pct']}%")

    st.subheader("Anomalies")
    st.dataframe(pd.DataFrame(report["anomalies"]) if report["anomalies"] else pd.DataFrame([{"info": "None detected"}]),
                 use_container_width=True)

    st.subheader("Forecast (next 3 months)")
    st.dataframe(pd.DataFrame(report["forecast"]), use_container_width=True)

    if report.get("recommendation"):
        rec = report["recommendation"]
        st.subheader("Recommendation")
        st.markdown(f"- **Finding:** {rec['finding']}\n- **Recommendation:** {rec['recommendation']}\n"
                    f"- **Expected impact:** {rec['expected_impact']}")

    st.divider()
    st.subheader("Export")
    col1, col2, col3 = st.columns(3)
    for col, fmt, label, mime in [
        (col1, "pdf", "Download PDF", "application/pdf"),
        (col2, "xlsx", "Download Excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
        (col3, "csv", "Download CSV", "text/csv"),
    ]:
        with col:
            file_bytes = requests.get(f"{API}/api/reports/{period}/export/{fmt}", timeout=30).content
            st.download_button(label, data=file_bytes, file_name=f"{period}_report.{fmt}", mime=mime)
