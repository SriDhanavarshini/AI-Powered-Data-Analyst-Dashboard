"""Sales analytics page."""
import requests
import streamlit as st
import plotly.express as px
import pandas as pd
import os

API = os.getenv("API_BASE_URL", "http://localhost:8000")
st.set_page_config(page_title="Sales Analytics", layout="wide")
st.title("Sales Analytics")

regional = requests.get(f"{API}/api/regional-performance", timeout=10).json()
category = requests.get(f"{API}/api/category-performance", timeout=10).json()
top_products = requests.get(f"{API}/api/top-products", timeout=10).json()

st.subheader("Regional performance")
st.dataframe(pd.DataFrame(regional), use_container_width=True)

st.subheader("Category performance")
c1, c2 = st.columns(2)
with c1:
    st.dataframe(pd.DataFrame(category), use_container_width=True)
with c2:
    if category:
        st.plotly_chart(px.bar(category, x="category", y="profit", title="Profit by category"), use_container_width=True)

st.subheader("Top products")
st.dataframe(pd.DataFrame(top_products), use_container_width=True)
