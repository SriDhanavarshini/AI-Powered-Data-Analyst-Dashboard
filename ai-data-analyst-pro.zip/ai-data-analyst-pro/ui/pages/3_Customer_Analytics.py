"""Customer analytics page — RFM segments and churn risk."""
import requests
import streamlit as st
import plotly.express as px
import pandas as pd
import os

API = os.getenv("API_BASE_URL", "http://localhost:8000")
st.set_page_config(page_title="Customer Analytics", layout="wide")
st.title("Customer Analytics")

st.subheader("RFM segments")
segments = requests.get(f"{API}/api/customer-segments", timeout=10).json()
if segments:
    df = pd.DataFrame(list(segments.items()), columns=["segment", "count"])
    st.plotly_chart(px.bar(df, x="segment", y="count", title="Customers by RFM segment"), use_container_width=True)

st.subheader("Churn risk (top 20 highest risk)")
churn = requests.get(f"{API}/api/churn-risk", timeout=15).json()
if churn.get("error"):
    st.info(churn["error"])
else:
    st.caption(f"Model holdout accuracy: {churn['model_accuracy']} (heuristic label — treat as directional, not certain)")
    st.dataframe(pd.DataFrame(churn["customers"]), use_container_width=True)
