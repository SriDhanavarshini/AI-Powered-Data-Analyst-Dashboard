"""Data quality dashboard."""
import requests
import streamlit as st
import os

API = os.getenv("API_BASE_URL", "http://localhost:8000")
st.set_page_config(page_title="Data Quality", layout="wide")
st.title("Data Quality")

dq = requests.get(f"{API}/api/data-quality", timeout=10).json()

c1, c2, c3, c4 = st.columns(4)
c1.metric("Data quality score", f"{dq['quality_score']}%")
c2.metric("Missing values", f"{dq.get('missing_values_pct', 0)}%")
c3.metric("Duplicates", f"{dq.get('duplicates_pct', 0)}%")
c4.metric("Invalid records", f"{dq.get('invalid_records_pct', 0)}%")

st.caption(f"Rows evaluated: {dq['row_count']:,}")
