"""Alert history page — configurable rules evaluated on a schedule (see app/alerts/rules.py)."""
import requests
import streamlit as st
import pandas as pd
import os

API = os.getenv("API_BASE_URL", "http://localhost:8000")
st.set_page_config(page_title="Alerts", layout="wide")
st.title("Alerts")

st.caption(
    "Rules run automatically every 6 hours: revenue drop > 10%, profit margin < 15%, "
    "return rate > 15%. You can also trigger a check manually below."
)

if st.button("Run alert check now"):
    with st.spinner("Evaluating rules..."):
        result = requests.post(f"{API}/api/alerts/check", timeout=20).json()
        if result["triggered_count"] == 0:
            st.success("No alerts triggered — all metrics within thresholds.")
        else:
            st.warning(f"{result['triggered_count']} alert(s) triggered.")
            for a in result["triggered"]:
                st.write(f"**[{a['severity'].upper()}] {a['rule_name']}** — {a['message']}")

st.subheader("Alert history")
history = requests.get(f"{API}/api/alerts/history", timeout=10).json()
if history:
    st.dataframe(pd.DataFrame(history), use_container_width=True)
else:
    st.info("No alerts recorded yet.")
