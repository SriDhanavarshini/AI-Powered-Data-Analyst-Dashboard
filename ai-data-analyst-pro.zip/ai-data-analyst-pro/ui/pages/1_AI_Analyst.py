"""AI Analyst chat page — natural language questions over the data."""
import requests
import streamlit as st
import pandas as pd
import os

API = os.getenv("API_BASE_URL", "http://localhost:8000")

st.set_page_config(page_title="AI Analyst", layout="wide")
st.title("AI Analyst")
st.caption("Ask questions like: \"What was total revenue?\", \"Why did revenue decrease in August?\", "
           "\"Forecast revenue for the next 3 months\", \"Find unusual sales behavior\", "
           "\"What happens if sales increase by 10%?\" — then try a follow-up like "
           "\"which region caused it\" to see conversational memory in action.")

if "history" not in st.session_state:
    st.session_state.history = []
if "context" not in st.session_state:
    st.session_state.context = {}

col_q, col_clear = st.columns([5, 1])
with col_q:
    question = st.text_input("Ask anything about your data")
with col_clear:
    st.write("")
    if st.button("Clear memory"):
        st.session_state.context = {}
        st.session_state.history = []
        st.rerun()

if st.button("Analyze") and question.strip():
    with st.spinner("Analyzing..."):
        try:
            resp = requests.post(
                f"{API}/api/ask",
                json={"question": question, "context": st.session_state.context},
                timeout=30,
            )
            resp.raise_for_status()
            result = resp.json()
            # persist the returned context so the next question can build on this one
            st.session_state.context = result.get("context", {})
            st.session_state.history.append((question, result))
        except Exception as e:
            st.error(f"Request failed: {e}")

for q, result in reversed(st.session_state.history):
    st.markdown(f"**Q: {q}**")
    st.write(result.get("answer", ""))

    if result.get("sql"):
        with st.expander("Generated SQL"):
            st.code(result["sql"], language="sql")

    for key in ("table", "region_table", "category_table"):
        if result.get(key):
            st.dataframe(pd.DataFrame(result[key]), use_container_width=True)

    if result.get("recommendation"):
        rec = result["recommendation"]
        st.markdown("**Recommendation**")
        st.markdown(f"- **Finding:** {rec['finding']}\n"
                    f"- **Evidence:** {rec['evidence']}\n"
                    f"- **Possible driver:** {rec['possible_driver']}\n"
                    f"- **Recommendation:** {rec['recommendation']}\n"
                    f"- **Expected impact:** {rec['expected_impact']}")

    if result.get("intent") == "what_if":
        st.markdown(
            f"Current: ₹{result['current_revenue']:,.0f} → Scenario: ₹{result['scenario_revenue']:,.0f} "
            f"({'+' if result['difference'] >= 0 else ''}{result['difference']:,.0f}, {result['change_pct']}%)"
        )
    st.divider()
