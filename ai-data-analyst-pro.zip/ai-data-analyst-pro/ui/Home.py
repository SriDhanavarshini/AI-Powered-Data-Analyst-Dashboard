"""Streamlit entrypoint — Overview / Executive Dashboard."""
import requests
import streamlit as st
import plotly.express as px
import os

API = os.getenv("API_BASE_URL", "http://localhost:8000")

st.set_page_config(page_title="AI Data Analyst Pro", layout="wide")
st.title("AI Data Analyst Pro — Overview")

try:
    kpis = requests.get(f"{API}/api/kpis", timeout=10).json()
except Exception as e:
    st.error(f"Could not reach the API at {API}. Is the backend running? ({e})")
    st.stop()

c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("Revenue", f"₹{kpis['revenue']:,.0f}")
c2.metric("Profit", f"₹{kpis['profit']:,.0f}")
c3.metric("Orders", f"{kpis['orders']:,}")
c4.metric("Avg Order Value", f"₹{kpis['aov']:,.0f}")
c5.metric("Profit Margin", f"{kpis['profit_margin_pct']}%")

st.divider()
col1, col2 = st.columns(2)

with col1:
    monthly = requests.get(f"{API}/api/monthly-revenue", timeout=10).json()
    if monthly:
        fig = px.line(monthly, x="month", y="revenue", title="Monthly revenue trend", markers=True)
        st.plotly_chart(fig, use_container_width=True)

with col2:
    regional = requests.get(f"{API}/api/regional-performance", timeout=10).json()
    if regional:
        fig = px.bar(regional, x="region", y="revenue", title="Revenue by region")
        st.plotly_chart(fig, use_container_width=True)

col3, col4 = st.columns(2)
with col3:
    category = requests.get(f"{API}/api/category-performance", timeout=10).json()
    if category:
        fig = px.pie(category, names="category", values="revenue", title="Revenue by category")
        st.plotly_chart(fig, use_container_width=True)

with col4:
    top_products = requests.get(f"{API}/api/top-products", timeout=10).json()
    if top_products:
        fig = px.bar(top_products, x="product_name", y="revenue", title="Top 10 products by revenue")
        st.plotly_chart(fig, use_container_width=True)

st.caption("Use the sidebar to open the AI Analyst chat, customer analytics, and data quality pages.")
